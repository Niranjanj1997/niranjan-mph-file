package com.mphasis.Book.repository;


import java.util.List;



import org.springframework.context.annotation.Scope;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


import com.mphasis.Book.Domain.Book;

@Repository("bookStoreRepository")
@Scope("singleton")
public interface BookStoreRepository extends MongoRepository<Book,String>{
List<Book> findBookBytitle(String title);	
List<Book> findAllBookByPublisher(String publisher);

List<Book> findAllBookByYear(int year);
}

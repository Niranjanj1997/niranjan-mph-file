CREATE SCHEMA books;

USE books;

CREATE TABLE book_details(
   book_id INT NOT NULL AUTO_INCREMENT,
   book_title VARCHAR(255),
   book_publisher VARCHAR(255),
   book_year INT);
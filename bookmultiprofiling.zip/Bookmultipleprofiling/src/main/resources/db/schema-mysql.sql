
USE books;


DROP TABLE IF EXISTS book_details;
CREATE TABLE book_details(
      book_id INT PRIMARY KEY AUTO_INCREMENT,
      book_title VARCHAR(255),
      book_publisher VARCHAR(255),
      book_year INT 
      );
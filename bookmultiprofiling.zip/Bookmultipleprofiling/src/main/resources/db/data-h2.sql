INSERT INTO books.book_details(book_title, book_publisher, book_year) VALUES('ENGLISH','RAJESH',2050);

INSERT INTO books.book_details(book_title, book_publisher, book_year) VALUES('PHYSICS','POOJA',2019);
INSERT INTO books.book_details(book_title, book_publisher, book_year) VALUES('MATHS','RUSH',2001);
package com.mphasis.Book.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.Book.Domain.Book;
import com.mphasis.Book.service.BookStoreService;

@Controller
@Scope("request")
public class BookMvcController {
	
	
	@Autowired
	@Qualifier("bookStoreService")
	private BookStoreService bookStoreService;
	
	@GetMapping("/allbooks")
	public ModelAndView getBooks() {
		
		ModelAndView mv=new ModelAndView();
		
		
		mv.addObject("books",bookStoreService.getallBooks());
		mv.setViewName("index.html");
		return mv;
		
	}
	
	
	@GetMapping("/allnewbook")
	public String allnewbook(Model model)
	{
	Book book=new Book();
		model.addAttribute("book",book);
	
		
		return "new_book" ;
		
	}
	

	@PostMapping("/savebook")
	public String addnewbook(@ModelAttribute ("book") Book book)
	{
		bookStoreService.save(book);
		return "redirect:/";
	}
	

}
